const form      = document.getElementById("form");
const urlInput  = document.getElementById("url");
const quality   = document.getElementById("quality");
const btn       = document.getElementById("btn");
const btnLabel  = btn.querySelector(".btn-label");
const spinner   = btn.querySelector(".spinner");
const statusBox = document.getElementById("status");
const resultBox = document.getElementById("result");
const progress  = document.getElementById("progress");
const steps     = [...document.querySelectorAll(".step")];

let pollTimer = null;

function setStep(step) {
  const order = ["searching", "downloading"];
  const idx = order.indexOf(step);
  steps.forEach((el, i) => {
    el.classList.remove("active", "done");
    if (i < idx) el.classList.add("done");
    if (i === idx) el.classList.add("active");
  });
}

function showError(msg) {
  resultBox.innerHTML = `<div class="error-card">⚠️ ${msg}</div>`;
  resultBox.classList.add("show");
}

function showResult(jobId, data) {
  const name = data.file || "video.mp4";
  resultBox.innerHTML = `
    <div class="result-card">
      <div class="title">✅ Video berhasil diproses</div>
      <div class="name">${data.title || name}</div>
      <a class="dl-btn" href="/download/${jobId}">⬇ Unduh file video</a>
    </div>`;
  resultBox.classList.add("show");
  resultBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = urlInput.value.trim();
  if (!url) return;

  clearTimeout(pollTimer);
  resultBox.innerHTML = "";
  resultBox.classList.remove("show");
  progress.style.width = "0%";
  statusBox.classList.add("show");
  setStep("searching");
  btn.disabled = true;
  btnLabel.textContent = "Memproses…";
  spinner.hidden = false;

  try {
    const res = await fetch("/api/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, quality: quality.value }),
    });
    const data = await res.json();
    if (!res.ok || data.error) throw new Error(data.error || "Gagal memulai");
    poll(data.job_id);
  } catch (err) {
    finishWithError(err.message);
  }
});

async function poll(jobId) {
  try {
    const res  = await fetch(`/api/status/${jobId}`);
    const data = await res.json();

    if (data.status === "error") return finishWithError(data.error || "Terjadi kesalahan");
    if (data.status === "done") {
      statusBox.classList.remove("show");
      showResult(jobId, data);
      btn.disabled = false;
      btnLabel.textContent = "Cari & Unduh";
      spinner.hidden = true;
      return;
    }

    if (data.status === "searching")   setStep("searching");
    if (data.status === "downloading") {
      setStep("downloading");
      progress.style.width = (data.progress || 0) + "%";
    }

    pollTimer = setTimeout(() => poll(jobId), 700);
  } catch {
    finishWithError("Koneksi ke server terputus.");
  }
}

function finishWithError(msg) {
  clearTimeout(pollTimer);
  statusBox.classList.remove("show");
  showError(msg);
  btn.disabled = false;
  btnLabel.textContent = "Cari & Unduh";
  spinner.hidden = true;
}