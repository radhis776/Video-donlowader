from flask import Flask, render_template, request, jsonify, send_from_directory
import yt_dlp
import os, uuid, threading, time

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DOWNLOAD_DIR = os.path.join(BASE_DIR, "downloads")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

jobs = {}  # job_id -> {status, progress, title, file, error}


def worker(url, job_id, quality):
    try:
        jobs[job_id] = {"status": "searching", "progress": 0, "title": None}

        # 1) Ambil metadata dulu (tanpa download) → deteksi situs & judul
        ydl_info_opts = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            # Generic extractor otomatis jadi fallback kalau situs tak punya extractor khusus
            "default_search": "auto",
        }
        with yt_dlp.YoutubeDL(ydl_info_opts) as ydl:
            info = ydl.extract_info(url, download=False)

        title = info.get("title", "video")
        jobs[job_id]["title"] = title
        jobs[job_id]["status"] = "downloading"

        # 2) Tentukan format
        #    bestvideo*+bestaudio/best → kualitas terbaik, lalu merge pakai ffmpeg[reference:1]
        if quality == "audio":
            fmt = "bestaudio/best"
            postprocessors = [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }]
        else:
            height = quality if quality in ("2160", "1440", "1080", "720", "480", "360") else "1080"
            # Utamakan mp4; kalau tidak ada, ambil apa saja yang terbaik
            fmt = (
                f"bestvideo[height<={height}][ext=mp4]+bestaudio[ext=m4a]/"
                f"bestvideo[height<={height}]+bestaudio/"
                f"best[height<={height}]/best"
            )
            postprocessors = [{
                "key": "FFmpegVideoRemuxer",
                "preferedformat": "mp4",
            }]

        outtmpl = os.path.join(DOWNLOAD_DIR, f"{job_id}_%(title).80s.%(ext)s")

        def hook(d):
            if d["status"] == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate")
                if total:
                    jobs[job_id]["progress"] = int(d["downloaded_bytes"] / total * 100)
            elif d["status"] == "finished":
                jobs[job_id]["progress"] = 100

        ydl_opts = {
            "outtmpl": outtmpl,
            "format": fmt,
            "progress_hooks": [hook],
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "merge_output_format": "mp4",
            "postprocessors": postprocessors,
            # === OPSIONAL: aktifkan cookies kalau butuh konten private/age-restricted ===
            # "cookiefile": os.path.join(BASE_DIR, "cookies.txt"),
        }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        # 3) Cari file hasil
        for f in os.listdir(DOWNLOAD_DIR):
            if f.startswith(job_id):
                jobs[job_id]["status"] = "done"
                jobs[job_id]["file"] = f
                return

        jobs[job_id]["status"] = "error"
        jobs[job_id]["error"] = "File hasil tidak ditemukan."

    except Exception as e:
        jobs[job_id] = {"status": "error", "error": str(e)}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/download", methods=["POST"])
def start():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    quality = data.get("quality", "1080")

    if not url.startswith("http"):
        return jsonify({"error": "URL tidak valid"}), 400

    job_id = uuid.uuid4().hex[:10]
    jobs[job_id] = {"status": "starting", "progress": 0}
    threading.Thread(target=worker, args=(url, job_id, quality), daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/api/status/<job_id>")
def status(job_id):
    if job_id not in jobs:
        return jsonify({"error": "Job tidak ditemukan"}), 404
    return jsonify(jobs[job_id])


@app.route("/download/<job_id>")
def download(job_id):
    if job_id not in jobs or "file" not in jobs[job_id]:
        return "File tidak ditemukan", 404
    return send_from_directory(DOWNLOAD_DIR, jobs[job_id]["file"], as_attachment=True)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)